# MedBooking — serverga joylash

Bu paket **statik sayt**: `index.html` (butun ilova bitta faylda) + `sw.js` (oflayn kesh) + `icon.svg`.
Node, Python yoki ma'lumotlar bazasi **kerak emas**, istalgan veb-server fayllarni uzatsa yetadi.

## Fayllar
| Fayl | Vazifasi |
|---|---|
| `index.html` | Butun sayt (demo versiya: kassa, navbat, karta orqali to'lov, xodimlar, yon menyu) |
| `sw.js` | Service worker (oflayn ochish). Yangi versiya chiqarsangiz ichidagi `VERSION` ni o'zgartiring |
| `icon.svg`, `robots.txt` | Ikonka, qidiruv robotlari uchun |
| `nginx.conf` | nginx sozlamasi (xavfsizlik sarlavhalari, CSP, kesh) |
| `Dockerfile`, `docker-compose.yml` | Docker bilan ishga tushirish |
| `Caddyfile` | HTTPS ni avtomatik oladigan eng oson variant |
| `.htaccess` | Apache yoki oddiy hosting uchun |

## 1-usul: Docker (tavsiya)
```bash
scp -r medbooking user@SERVER:~/ && ssh user@SERVER
cd medbooking && docker compose up -d --build
```
Sayt `http://SERVER_IP/` da ochiladi.

## 2-usul: Caddy (HTTPS bilan, eng oson)
1. Domen A yozuvini server IP siga yo'naltiring.
2. `Caddyfile` dagi `domen.uz` ni o'z domeningizga almashtiring.
3. Fayllarni `/srv` ga joylang va `caddy run --config Caddyfile`.

## 3-usul: nginx
```bash
sudo mkdir -p /var/www/medbooking
sudo cp index.html sw.js icon.svg robots.txt /var/www/medbooking/
sudo cp nginx.conf /etc/nginx/conf.d/medbooking.conf   # ichida root /var/www/medbooking va server_name ni to'g'rilang
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d medbooking.uz                   # HTTPS
```

## 4-usul: oddiy hosting (cPanel va h.k.)
`index.html`, `sw.js`, `icon.svg`, `.htaccess` ni `public_html` ga yuklang.

## Muhim: HTTPS shart
Joylashuv ("Yaqinimdagi klinikalar"), mikrofon/kamera (video qo'ng'iroq), service worker va PWA o'rnatish faqat **HTTPS** da ishlaydi.

## Tekshirish ro'yxati
- [ ] Sayt ochiladi, yon menyu (kompyuterda) va pastki menyu (telefonda) ko'rinadi
- [ ] Brauzer konsolida xato yo'q (F12)
- [ ] `https://domen.uz/sw.js` ochiladi, sahifa "O'rnatish" ni taklif qiladi
- [ ] Yangilangandan keyin eski versiya ko'rinsa: brauzerda qattiq yangilash (Ctrl+Shift+R) yoki `VERSION` ni oshiring

## Ogohlantirish: bu hali demo
Bu fayl **brauzer ichida ishlaydigan demo**. Haqiqiy foydalanuvchilar uchun tayyor emas:
- Ma'lumotlar (qabullar, foydalanuvchilar, parollar) har bir brauzerning `localStorage` ida saqlanadi: bir qurilmadagi ma'lumotni boshqasi ko'rmaydi, tozalansa yo'qoladi.
- SMS, Telegram, Click, Payme va bank kartasi to'lovlari **simulyatsiya**. Haqiqiy pul yechilmaydi, SMS yuborilmaydi.
- Kirish va rollar (admin, kassir, shifokor) faqat interfeys darajasida, server tomonida himoya yo'q. Haqiqiy bemor ma'lumotini kiritmang.
- Shriftlar Google Fonts dan yuklanadi (internet kerak, bo'lmasa tizim shrifti ishlatiladi).

Haqiqiy ishga tushirish uchun backend kerak: FastAPI + Postgres loyihasiga ko'chirish (SMS provayder, Click/Payme merchant, bank ekvayring shartnomasi, Telegram bot tokeni). Bu keyingi bosqich.
